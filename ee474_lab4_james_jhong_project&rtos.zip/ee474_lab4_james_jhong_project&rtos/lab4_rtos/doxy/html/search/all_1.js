var searchData=
[
  ['ocr_5fcalc_0',['ocr_calc',['../lab4__rtos_8c.html#a8c548176023091d7db44fb2ee74db790',1,'lab4_rtos.c']]]
];
