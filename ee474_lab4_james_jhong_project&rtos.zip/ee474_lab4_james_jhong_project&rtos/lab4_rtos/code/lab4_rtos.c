/**
 * @file lab4_rtos.c
 * This is the source code for part 4.3 in Lab 4 for EE474
 */

//James Jhong
//EE 474
//Lab 4 part 3

#include <Arduino_FreeRTOS.h>
#include <FreeRTOSConfig.h>
#include <arduinoFFT.h>
#include <queue.h>

#define NOTE_d 293
#define NOTE_e 329
#define NOTE_c4 261
#define NOTE_c3 130
#define NOTE_g3 196
#define melody_length 1000
#define speaker_bit 1 << 3

#define LED_PIN 47
#define SPEAK_PIN 6

static QueueHandle_t FFTQ;
static QueueHandle_t qWallTimes;

arduinoFFT FFT = arduinoFFT();
const uint16_t samples = 128;

static double randomDoubles[samples];

void taskRT1(void *pvParameters);
void taskRT2(void *pvParameters);
void taskRT3p1(void *pvParameters);
void taskRT3p0(void *pvParameters);
void taskRT4(void *pvParameters);

/** @brief
 *  This task sets up timer4 for use with the tasks in this lab.
 */

void timerSetup() {
  //initializing
  TCCR4A = 0;
  TCCR4B = 0;
  TCNT4 = 0;

  //setting up values
  TCCR4A |= (1 << COM4A0); //Toggling on compare match
  TCCR4B |= (1 << WGM42); //CTC MODE
  TCCR4B |= (1 << CS40); //Prescalar 1
  OCR4A = 0;

}

void setup() {
  Serial.begin(19200);
  xTaskCreate(
    taskRT1
    ,  "Blink"   // A name just for humans
    ,  500  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  2  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  NULL );

  timerSetup();
  xTaskCreate(
    taskRT2
    , "Close Encounters Speaker"
    , 700
    , NULL
    , 1
    , NULL);

  xTaskCreate(
    taskRT3p0
    , "Pseudo Nums Queue"
    , 400
    , NULL
    , 1
    , NULL);
  
  xTaskCreate(
    taskRT4
    , "FFT Compute"
    , 1350
    , NULL
    , 1
    , NULL);    
  vTaskStartScheduler();
}

/** @brief
 *  Calculates the OCR value based on the desired frequency designed with a prescalar of 256 in mind.
 */
void ocr_calc(int freq) {  
  if (freq == 0) {
    OCR4A = 0;
  } else {
    OCR4A = (16000000 / (2 * freq)) - 1 ;
  }
}

void loop() {
  // put your main code here, to run repeatedly:

}


/******************* BEGINNING OF TASKS ***********************/

/** @brief
 *  This tasks flashes an off board LED on for 100 ms and off for 200 ms
 */
void taskRT1(void *pvParameters) {
  vTaskDelay(50 / portTICK_PERIOD_MS );
  pinMode(LED_PIN, OUTPUT); 

  for (;;) //Runs infinitely
  {
     digitalWrite(LED_PIN, HIGH);
     vTaskDelay( 100 / portTICK_PERIOD_MS ); //on for 100 ms
     digitalWrite(LED_PIN, LOW);
     vTaskDelay( 200 / portTICK_PERIOD_MS ); //off for 200 ms
  }
}

/** @brief
 *  This task plays the theme from Close Encounters for a total of 3 times with a 1.5 second pause in between. 
 */

void taskRT2(void *pvParameters) {
  vTaskDelay(50 / portTICK_PERIOD_MS ); //Syncing up to 50 ms
  static int so_timer;
    
    DDRH |= speaker_bit; //turning on speaker
    for (;;) {
      
     if (so_timer == melody_length * 8) {
      so_timer = 0;
     }

     //at 1 second increments, plays the next note in the close encounters theme
     if (so_timer < melody_length) {
       ocr_calc(NOTE_d);
     } else if (so_timer < melody_length * 2) {
       ocr_calc(NOTE_e);
     } else if (so_timer < melody_length * 3) {
       ocr_calc(NOTE_c4);
     } else if (so_timer < melody_length * 4){
       ocr_calc(NOTE_c3);
     } else if (so_timer < melody_length * 5){
       ocr_calc(NOTE_g3);
     } else {
       ocr_calc(0);
     }
     so_timer += 100; //incrementing time by 100 "slowed" down the output to sound clean
     vTaskDelay(50 / portTICK_PERIOD_MS ); //more syncing delay
   }
}

void taskRT3p0(void *pvParameters) {
  vTaskDelay(50 / portTICK_PERIOD_MS ); //Syncing up to 50 ms
  FFTQ = xQueueCreate(samples, sizeof(uint16_t)); 

  for (uint16_t i = 0; i < samples; i++) { //making randomDoubles array
    randomDoubles[i] = double(random());
  }
  //now creating task 3 main
  xTaskCreate(
      taskRT3p1
      , "Calculation Average Times"
      , 1200
      , NULL
      , 3
      , NULL); 
    //halting RT3p0
   vTaskDelete( NULL );
}

/**
 * @brief TaskRT3p1
 * Initialize a queue to hold FFT calculation times and sending
 * it to task 4 to be filled up using the random values from queue in 3p0
 */
void taskRT3p1(void *pvParameters) {
  vTaskDelay(50 / portTICK_PERIOD_MS ); //Syncing up to 50 ms
  static int time;
  qWallTimes = xQueueCreate(samples, sizeof(uint16_t)); //creating queue
  
  for(;;) {
    xQueueSendToBack(FFTQ, randomDoubles, 10); //sending double values to be calculated to task 4 
    if (xQueueReceive(qWallTimes, &time, 20) == pdPASS) { //Printing to serial upon receival of wall times after 5 fft computes
      Serial.print("Wait Time: "); 
      Serial.print(time);
      Serial.println(" milliseconds");
    }
  }
}

/** @brief
 *  Computes 5 FFTs of pseudo numbers from taskRTp1 and records the time taken to do FFT calculations
 *  and send this time back to Task 3 across a queue. 
 */
void taskRT4(void *pvParamters) {
  vTaskDelay(50 / portTICK_PERIOD_MS ); //Syncing up to 50 ms
  static int time; //vars for millis
  static int curTime;
  static int startTime;
  static double vReal[samples]; //fields required by FFT
  static double vImag[samples];
  for (;;) {
    if(xQueueReceive(FFTQ, vReal, 20) == pdPASS){ 
      startTime = millis();
      uint16_t i;
      //doing 5 computations
      for (i = 0; i < 5; i++){
        FFT.Compute(vReal, vImag, samples, FFT_FORWARD);
      }
      curTime = millis();
      time = (curTime - startTime);
      xQueueSendToBack(qWallTimes, &(time), 20); //filling queue with computation time
    }
  }   
}