var searchData=
[
  ['scarebuzz_0',['scareBuzz',['../mole__detector_8c.html#aa7e73b4ebd4bc83436160f4b22242c9d',1,'mole_detector.c']]],
  ['sensortask_1',['sensorTask',['../mole__detector_8c.html#a217451a0ec75f826e5a2933c3268c7c2',1,'mole_detector.c']]],
  ['setup_2',['setup',['../mole__detector_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'mole_detector.c']]]
];
