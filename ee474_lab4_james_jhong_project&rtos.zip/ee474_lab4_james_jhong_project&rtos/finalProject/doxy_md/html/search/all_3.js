var searchData=
[
  ['ocr_5fcalc_0',['ocr_calc',['../mole__detector_8c.html#a8c548176023091d7db44fb2ee74db790',1,'mole_detector.c']]]
];
